package Buyer.Resturant;
import Buyer.Resturant.Items.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Management {
    private Menue myMenue = new Menue();

    public void placeOrder(String fName, int n) {
        myMenue.buy(fName, n);
    }
    public void checkMenue(){
        myMenue.seeFoods();
    }
    public Menue getMenue(){
        return myMenue;
    }
    public void removeFromMenue(String name){
        myMenue.deleteFood(name);
    }
    public void addNewFood(String name, int quantity, double price){
        myMenue.addFood(name, quantity, price);
    }
    public void launchGui(){       
        JFrame frame = new JFrame();
        frame=new JFrame();   

        Font font = new Font("Helvetica", Font.BOLD, 20);
        
        
        String column[]={"Food Name","Price"};         
        JTable jt=new JTable(myMenue.getData(),column);    
        jt.setBounds(100,40,1000,400);
        jt.setBackground(new Color(238,238,238,255));
        jt.setShowGrid(false);         
        jt.setShowHorizontalLines(true);
        jt.setFont(font);
        jt.setRowHeight(30);
        frame.setFont(font);


        JScrollPane sp = new JScrollPane();  
        sp.setLayout(null);
        sp.setBounds(0,0,1200,800); 
; 
        
        JPanel myPanel = new JPanel();

        myPanel.setBounds(0, 0, 1200, 800);
        myPanel.setLayout(null);
        sp.add(jt);


        JTextField foodName = new JTextField();
        JTextField foodAmmount = new JTextField();
        
        foodName.setBounds(500, 600, 200, 32);
        foodAmmount.setBounds(500, 650, 200, 32);
        
        myPanel.add(foodName, BorderLayout.CENTER);
        myPanel.add(foodAmmount, BorderLayout.CENTER);

        JButton button = new JButton("order");
        button.setBounds(565, 700, 70, 40);
        button.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                String name = foodName.getText();
                String amount = foodAmmount.getText();
                int amount1 = Integer.parseInt(amount);
                placeOrder(name, amount1);
            }
        });
        sp.add(button, BorderLayout.CENTER);

        sp.add(foodName);
        sp.add(foodAmmount);
        sp.add(button);
        //sp.add(myPanel);
        myPanel.add(sp);
        frame.add(myPanel);         
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        frame.setSize(1200,800);    
        frame.setLayout(null);
        frame.setVisible(true); 
    }

}