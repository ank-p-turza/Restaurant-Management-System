package Buyer;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.jar.JarFile;

public class Customer extends JFrame{
        public static String TABLE;
        public Customer(){
        String[] optionsToChoose = {"Table 1", "Table 2", "Table 3", "Table 5", "Table 5", "Table 6","Table 7","Table 8","Table 9","Table 10"};

        JFrame jFrame = new JFrame();

        JComboBox<String> jComboBox = new JComboBox<>(optionsToChoose);
        jComboBox.setBounds(420, 300, 300, 50);

        JButton jButton = new JButton("Select");
        jButton.setBounds(500, 380, 150, 50);


        jFrame.add(jButton);
        jFrame.add(jComboBox);
        
        jFrame.setLayout(null);
        jFrame.setSize(1200, 800);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setResizable(false);
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TABLE = jComboBox.getItemAt(jComboBox.getSelectedIndex());
                jFrame.dispose();
                new Shop();
            }
        });
    }
}
