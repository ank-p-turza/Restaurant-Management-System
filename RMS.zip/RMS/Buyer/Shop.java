package Buyer;
import Buyer.Resturant.*;
// import java.util.Scanner;
// import java.awt.*;
// import java.awt.event.*;




public class Shop {
    public Shop() {
        // Scanner scan = new Scanner(System.in);
        Management management = new Management();
        // String name;
        // int quantity;
        //management.removeFromMenue("burger");
        management.launchGui();        
        
        
        //****************************************************************** */
        //management.addNewFood("egg-sandwich", 300, 80);
        //*******************************************************************/




        // System.out.println("Welcome to the shop heres the menue:");
        // management.checkMenue();
        // System.out.println("What would you like to order?");
        // name = scan.nextLine();
        // System.out.println("enter the quantity");
        // quantity = scan.nextInt();
        // management.placeOrder(name, quantity);
    }
}