package Employee;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class trun {
    ArrayList<ArrayList<String>> TotInfo = new ArrayList<ArrayList<String>>();
    try {
        BufferedReader bw = new BufferedReader(new FileReader("D:\\Java Projects\\Restaurant  Management System\\Data\\Employee.txt"));
        String x = bw.readLine();
    } catch (Exception e) {
        //TODO: handle exception
    }

}
