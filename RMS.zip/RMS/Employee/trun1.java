package Employee;

import java.math.*;
import java.io.*;
import java.util.Scanner;
// import java.exc

import javax.sound.midi.VoiceStatus;

public class trun1 {
    int x = getNoOfEmployeee();
    String [][]TotInfo =  new String[x][];
    public int getNoOfEmployeee(){
        try{
            BufferedReader br = new BufferedReader(new FileReader("D:\\Java Projects\\Restaurant  Management System\\Data\\Employee.txt"));
            String line;
            int i = 0;
            line = br.readLine();
            while(line != null){
                line = br.readLine();
                i++;
            }
            return i;
        }catch(Exception e){
            return -1;
        }
    }
    public void init() {
        int size= getNoOfEmployeee();
        /*employye.txt format 
        * username;password;name;designation;email;phone;salary;address
        */
        try{
            BufferedReader br = new BufferedReader(new FileReader("D:\\Java Projects\\Restaurant  Management System\\Data\\Employee.txt"));
            String []info;
            String line[] = new String[size];

            for(int i=0;i<size;i++){
                line[i] = br.readLine();
                info = line[i].split(";");
                TotInfo[i] = info;
            }
            br.close();                
        }catch(Exception e){
            //System.out.println(e);
        }
    }

    public void rmEmployeeByID(String ID){
        init();
        for (int j = 0; j < TotInfo.length; j++) {
            if (TotInfo[j][0].equals(ID)) {
                TotInfo[j] = null;
                break;
            }
            //else{
                //JOptionPane.showMessageDialog(null, "Did not match");
                //break;
            //}
        }
    }
    public void showall(){
        
        for (int i = 0; i < TotInfo.length; i++) {
            if(TotInfo[i]!=null){
                System.out.println(TotInfo[i][0]/*+";"+TotInfo[i][1]+";"+TotInfo[i][2]+";"+TotInfo[i][3]+";"+TotInfo[i][4]+";"+TotInfo[i][5]+";"+TotInfo[i][6]+";"+TotInfo[i][7]*/+"\r\n");
            }
        }
    }




    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String d = sc.nextLine();
        trun tr = new trun();
        tr.rmEmployeeByID("waiter-3");
        tr.showall();

    }
}
